package rpg.ifgoiano.rpg.controle;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import rpg.ifgoiano.rpg.entidade.Produto;
import rpg.ifgoiano.rpg.service.ProdService;
import rpg.ifgoiano.rpg.service.ProdServiceImpl;


@Controller
public class ProdController{
	private final ProdService prodServiceImpl;

	public ProdController(ProdServiceImpl prodServiceImpl){
		this.prodServiceImpl = prodServiceImpl;

	}
	@GetMapping("/loja")
	public String pagInicial(Model model) {
		return "loja";
	}

	@GetMapping("/produto")
	public String listarProd(Model model){

		model.addAttribute("produto", prodServiceImpl.listarProdutos());

		return "hometwo"; 

	}

	@GetMapping("/produto/novo")
	public String abrirNovoPersonagem(Model model) {
		Produto produto = new Produto();

		model.addAttribute("produto", produto);

		return "inserirProduto";
	}

	@PostMapping("/produto/inserir")
	public String inserir(Produto produto) {

		this.prodServiceImpl.inserir(produto);
		return "redirect:/produto";
	}

	@GetMapping("/produto/alterar/{id}")
	public String abrirAlterar(@PathVariable Long id, Model model) {
		Produto produto = this.prodServiceImpl.obterProduto(id);

		model.addAttribute("produto", produto);

		this.prodServiceImpl.alterar(produto);
		return "alterar-produto";
	}

	@PostMapping("/produto/alterar")
	public String alterar(Produto produto) {
		this.prodServiceImpl.alterar(produto);
		return "redirect:/produto";
	}
	
	@GetMapping("/produto/deletar/{id}")
	public String deletarProd(@PathVariable Long id, Model model) {
		Produto produto = this.prodServiceImpl.obterProduto(id);
		
		model.addAttribute("produto", produto);
		
		this.prodServiceImpl.deletar(produto);
		return "redirect:/produto";
	}
	
	@PostMapping("/produto/deletar")
	public String deletar(Produto produto) {
		this.prodServiceImpl.deletar(produto);
		return "redirect:/produto";
	}
	
}