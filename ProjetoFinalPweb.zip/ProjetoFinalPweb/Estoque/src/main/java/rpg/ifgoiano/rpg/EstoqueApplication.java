package rpg.ifgoiano.rpg;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import rpg.ifgoiano.rpg.repositorio.ProdRepositorio;

@SpringBootApplication
public class EstoqueApplication {
    
    @Autowired
    private ProdRepositorio prodRepositorio;

	public static void main(String[] args) {
		SpringApplication.run(EstoqueApplication.class, args);
	}
	
	public void run(String... args) throws Exception {
        System.out.println("passou aqui");
    }

}
